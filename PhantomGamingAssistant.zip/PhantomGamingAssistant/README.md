# PHANTOM Gaming Assistant
Kotlin / Android Studio project. Floating button -> control panel -> lens window (magnifier 1x-5x + colour filter).

Build: open this folder in Android Studio (Koala or newer), let Gradle sync, then Build > Build APK(s).
Or from a terminal: ./gradlew assembleDebug  ->  app/build/outputs/apk/debug/app-debug.apk
Requires Android 8.0+ (API 26). Tunable: OverlayService.SCALE (capture resolution), LensView.P (filter resolution).
