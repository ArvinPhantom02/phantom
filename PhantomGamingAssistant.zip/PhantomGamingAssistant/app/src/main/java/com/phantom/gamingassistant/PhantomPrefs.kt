package com.phantom.gamingassistant

import android.content.Context

/** Persists every user setting between sessions. */
class PhantomPrefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("phantom_prefs", Context.MODE_PRIVATE)
    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun putI(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun putB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    var magnifierOn: Boolean get() = sp.getBoolean("mag", false); set(v) = putB("mag", v)
    var filterOn: Boolean get() = sp.getBoolean("filter", false); set(v) = putB("filter", v)
    var zoomTenths: Int get() = i("zoom", 20); set(v) = putI("zoom", v)        // 10..50 => 1.0x..5.0x
    var lensSizeDp: Int get() = i("size", 220); set(v) = putI("size", v)       // 120..400
    var opacity: Int get() = i("opacity", 100); set(v) = putI("opacity", v)    // 30..100
    var intensity: Int get() = i("intensity", 80); set(v) = putI("intensity", v) // 0..100
    var mode: Int get() = i("mode", 0); set(v) = putI("mode", v)               // 0..3
    var fabX: Int get() = i("fabX", -1); set(v) = putI("fabX", v)
    var fabY: Int get() = i("fabY", -1); set(v) = putI("fabY", v)
    var lensX: Int get() = i("lensX", -1); set(v) = putI("lensX", v)
    var lensY: Int get() = i("lensY", -1); set(v) = putI("lensY", v)
    var focusX: Int get() = i("focusX", -1); set(v) = putI("focusX", v)
    var focusY: Int get() = i("focusY", -1); set(v) = putI("focusY", v)
}
