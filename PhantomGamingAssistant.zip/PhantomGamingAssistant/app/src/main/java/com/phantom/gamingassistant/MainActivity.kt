package com.phantom.gamingassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

/** Setup screen: explains and requests permissions, then starts / stops the overlay service. */
class MainActivity : Activity() {
    private val red = Color.parseColor("#E5192B")
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(buildUi())
    }

    override fun onResume() { super.onResume(); updateStatus() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(40), dp(24), dp(32)) }
        col.addView(TextView(this).apply {
            text = "PHANTOM"; setTextColor(red); textSize = 38f; typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.3f; gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "GAMING ASSISTANT"; setTextColor(Color.GRAY); textSize = 13f; letterSpacing = 0.4f
            gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(24))
        })
        status = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, dp(12)) }
        col.addView(status)
        col.addView(btn("1 · Allow display over other apps", false) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("2 · Start PHANTOM", true) { onStart() })
        col.addView(btn("Stop PHANTOM", false) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        })
        col.addView(TextView(this).apply {
            setTextColor(Color.LTGRAY); textSize = 14f; setPadding(0, dp(24), 0, 0)
            text = """WHY THESE PERMISSIONS
• Display over other apps: lets PHANTOM draw its floating button, magnifier and filter window above your game.
• Screen capture: Android shows a system dialog every time. PHANTOM needs it to read the pixels it magnifies / recolours. Choose "Entire screen" on Android 14+. Nothing is recorded or sent anywhere.
• Notifications: Android requires a visible "running" notification, which also has a Stop button.

HOW TO USE
Tap Start, accept the prompts, open your game, then tap the red P button. Switch Magnifier and Thermal filter on or off independently. Drag the red ring to choose which part of the screen the window shows, and drag the window anywhere.

LIMITS (honest notes)
• Android does not let an app recolour other apps directly, so the filter is applied inside the floating window.
• The filter only recolours pixels that are already on your screen. It cannot see through walls or reveal hidden players.
• If an app blocks screen capture, the window stays black and PHANTOM tells you.
• PHANTOM does not modify or hook any game."""
        })
        return ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(col) }
    }

    private fun btn(label: String, primary: Boolean, click: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE); isAllCaps = false; textSize = 16f
        background = GradientDrawable().apply {
            setColor(if (primary) red else Color.parseColor("#141414")); setStroke(dp(1), red); cornerRadius = dp(12).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) }
        setOnClickListener { click() }
    }

    private fun updateStatus() {
        val ok = Settings.canDrawOverlays(this)
        status.text = if (ok) "✔ Overlay permission granted" else "✖ Overlay permission needed (step 1)"
        status.setTextColor(if (ok) Color.parseColor("#3DDC84") else red)
    }

    private fun onStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please allow display over other apps first.", Toast.LENGTH_LONG).show(); return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        } else requestCapture()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        requestCapture() // works even if notifications were denied; the notification is just hidden
    }

    private fun requestCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION") startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 100) return
        if (res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, OverlayService::class.java)
                .setAction(OverlayService.ACTION_START).putExtra("code", res).putExtra("data", data))
            Toast.makeText(this, "PHANTOM is running. Open your game and tap the red P.", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, "Screen capture was declined. The magnifier and filter need it to work.", Toast.LENGTH_LONG).show()
        }
    }
}
