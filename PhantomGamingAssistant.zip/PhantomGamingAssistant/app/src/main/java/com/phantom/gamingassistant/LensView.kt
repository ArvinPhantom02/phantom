package com.phantom.gamingassistant

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/** Latest captured frame, shared between the capture thread and the UI thread. */
class FrameStore {
    val lock = Any()
    var bitmap: Bitmap? = null
    var w = 0
    var h = 0
    var screenW = 1
    var screenH = 1
}

val MODE_NAMES = listOf("Thermal", "Infrared", "Grayscale", "High contrast")

private fun lerp(a: Int, b: Int, f: Float) = (a + (b - a) * f).toInt()
private fun palette(stops: IntArray): IntArray {
    val n = stops.size - 1
    return IntArray(256) { i ->
        val t = i / 255f * n
        val a = t.toInt().coerceAtMost(n - 1)
        val f = t - a
        val c0 = stops[a]; val c1 = stops[a + 1]
        Color.rgb(
            lerp(Color.red(c0), Color.red(c1), f),
            lerp(Color.green(c0), Color.green(c1), f),
            lerp(Color.blue(c0), Color.blue(c1), f)
        )
    }
}

private val THERMAL = palette(intArrayOf(
    0xFF000000.toInt(), 0xFF1A0050.toInt(), 0xFF7B00A8.toInt(), 0xFFE00020.toInt(),
    0xFFFF8A00.toInt(), 0xFFFFE600.toInt(), 0xFFFFFFFF.toInt()))
private val INFRARED = palette(intArrayOf(
    0xFF000000.toInt(), 0xFF3A0000.toInt(), 0xFFB00010.toInt(),
    0xFFFF4060.toInt(), 0xFFFFC0D0.toInt(), 0xFFFFFFFF.toInt()))

/**
 * The floating lens. It draws a region of the captured screen around the focus point,
 * enlarged by the zoom factor (when the magnifier is on) and recoloured (when the filter is on).
 */
class LensView(
    ctx: Context,
    private val store: FrameStore,
    private val prefs: PhantomPrefs,
    private val focus: () -> Pair<Float, Float>,
    private val onDrag: (Float, Float) -> Unit,
    private val onDragEnd: () -> Unit,
    private val onClose: () -> Unit
) : View(ctx) {

    private val red = Color.parseColor("#E5192B")
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = red; strokeWidth = 2 * d }
    private val closeBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = red }
    private val closeX = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 2.5f * d; strokeCap = Paint.Cap.ROUND }
    private val src = Rect()
    private val dst = Rect()
    private val P = 256 // working resolution of the per-pixel colour mapping (keeps it fast)
    private val proc = Bitmap.createBitmap(P, P, Bitmap.Config.ARGB_8888)
    private val procCanvas = Canvas(proc)
    private val procRect = Rect(0, 0, P, P)
    private val px = IntArray(P * P)
    private val closeSize = 40 * d

    override fun onDraw(c: Canvas) {
        dst.set(0, 0, width, height)
        synchronized(store.lock) {
            val bmp = store.bitmap
            if (bmp == null || store.w <= 0) {
                c.drawColor(Color.BLACK)
            } else {
                val sc = store.w.toFloat() / store.screenW
                val zoom = if (prefs.magnifierOn) prefs.zoomTenths / 10f else 1f
                val sw = width / zoom * sc
                val sh = height / zoom * sc
                val (fx, fy) = focus()
                val l = (fx * sc - sw / 2).coerceIn(0f, max(0f, store.w - sw))
                val t = (fy * sc - sh / 2).coerceIn(0f, max(0f, store.h - sh))
                src.set(l.toInt(), t.toInt(), (l + sw).toInt().coerceAtMost(store.w), (t + sh).toInt().coerceAtMost(store.h))
                drawContent(c, bmp)
            }
        }
        c.drawRect(d, d, width - d, height - d, border)
        val cx = width - 20 * d; val cy = 20 * d
        c.drawCircle(cx, cy, 14 * d, closeBg)
        c.drawLine(cx - 5 * d, cy - 5 * d, cx + 5 * d, cy + 5 * d, closeX)
        c.drawLine(cx + 5 * d, cy - 5 * d, cx - 5 * d, cy + 5 * d, closeX)
    }

    private fun drawContent(c: Canvas, bmp: Bitmap) {
        paint.colorFilter = null
        if (!prefs.filterOn) { c.drawBitmap(bmp, src, dst, paint); return }
        val k = prefs.intensity / 100f
        when (prefs.mode) {
            0, 1 -> {
                val pal = if (prefs.mode == 0) THERMAL else INFRARED
                procCanvas.drawBitmap(bmp, src, procRect, paint)
                proc.getPixels(px, 0, P, 0, 0, P, P)
                val a = (k * 256).toInt()
                for (i in px.indices) {
                    val p = px[i]
                    val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
                    val m = pal[(r * 77 + g * 151 + b * 28) shr 8]
                    val rr = r + (((m shr 16 and 0xFF) - r) * a shr 8)
                    val gg = g + (((m shr 8 and 0xFF) - g) * a shr 8)
                    val bb = b + (((m and 0xFF) - b) * a shr 8)
                    px[i] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
                }
                proc.setPixels(px, 0, P, 0, 0, P, P)
                c.drawBitmap(proc, null, dst, paint)
            }
            2 -> {
                paint.colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(1f - k) })
                c.drawBitmap(bmp, src, dst, paint)
            }
            else -> {
                val s = 1f + 2f * k; val t = 128f * (1f - s)
                paint.colorFilter = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                    s, 0f, 0f, 0f, t,  0f, s, 0f, 0f, t,  0f, 0f, s, 0f, t,  0f, 0f, 0f, 1f, 0f)))
                c.drawBitmap(bmp, src, dst, paint)
            }
        }
    }

    private var lx = 0f; private var ly = 0f; private var onClosePress = false
    private fun inClose(e: MotionEvent) = e.x > width - closeSize && e.y < closeSize

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; onClosePress = inClose(e) }
            MotionEvent.ACTION_MOVE -> if (!onClosePress) {
                onDrag(e.rawX - lx, e.rawY - ly); lx = e.rawX; ly = e.rawY
            }
            MotionEvent.ACTION_UP -> if (onClosePress && inClose(e)) onClose() else onDragEnd()
        }
        return true
    }
}

/** Small draggable ring that marks which part of the screen the lens shows. */
class CrosshairView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.parseColor("#99E5192B"); strokeWidth = 2 * d
    }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = width / 2f - 3 * d
        c.drawCircle(cx, cy, r, p)
        c.drawLine(cx - r, cy, cx - r * 0.45f, cy, p); c.drawLine(cx + r * 0.45f, cy, cx + r, cy, p)
        c.drawLine(cx, cy - r, cx, cy - r * 0.45f, p); c.drawLine(cx, cy + r * 0.45f, cx, cy + r, p)
    }
}
