package com.phantom.gamingassistant

import android.annotation.SuppressLint
import android.app.*
import android.content.ColorStateList
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Foreground service that owns the MediaProjection session and all overlay windows:
 * floating button, control panel, lens (magnifier + filter) and the focus ring.
 */
class OverlayService : Service() {
    companion object {
        const val ACTION_START = "com.phantom.gamingassistant.START"
        const val ACTION_STOP = "com.phantom.gamingassistant.STOP"
        const val SCALE = 0.75f // capture resolution relative to the screen; raise for sharper zoom, lower for speed
        private val RED = Color.parseColor("#E5192B")
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: PhantomPrefs
    private val store = FrameStore()
    private val main = Handler(Looper.getMainLooper())
    private var bgThread: HandlerThread? = null
    private var bg: Handler? = null
    private var projection: MediaProjection? = null
    private var projCallback: MediaProjection.Callback? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    @Volatile private var lensVisible = false
    private var lastFrame = 0L
    private var frameCount = 0
    private var blankCount = 0
    private var warned = false

    private var fab: View? = null
    private var fabLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelOpen = false
    private var lens: LensView? = null
    private var lensLp: WindowManager.LayoutParams? = null
    private var cross: CrosshairView? = null
    private var crossLp: WindowManager.LayoutParams? = null
    private lateinit var magSwitch: Switch
    private lateinit var filterSwitch: Switch
    private val loc = IntArray(2)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = PhantomPrefs(this)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (i?.action == ACTION_START && projection == null) {
            startFg() // must be in the foreground BEFORE obtaining the projection (Android 14+)
            try {
                val code = i.getIntExtra("code", 0)
                @Suppress("DEPRECATION")
                val data: Intent = (if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
                else i.getParcelableExtra("data"))!!
                bgThread = HandlerThread("phantom-capture").also { it.start() }
                bg = Handler(bgThread!!.looper)
                val mpm = getSystemService(MediaProjectionManager::class.java)
                val p = mpm.getMediaProjection(code, data)
                projection = p
                projCallback = object : MediaProjection.Callback() {
                    override fun onStop() { main.post { stopSelf() } } // user ended sharing from the system UI
                }
                p.registerCallback(projCallback!!, main) // required before createVirtualDisplay
                setupCapture()
                buildUi()
            } catch (e: Exception) {
                toast("Could not start screen capture: ${e.message}")
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("phantom", "PHANTOM", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, "phantom")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("PHANTOM is running")
            .setContentText("Floating tools are active. Tap Stop to remove them.")
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Stop", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------------------------------------------------------------- capture

    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds.let { it.width() to it.height() }
        else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }

    /** Creates (or, after a rotation, re-targets) the virtual display that mirrors the screen. */
    private fun setupCapture() {
        val (sw, sh) = screenSize()
        val cw = (sw * SCALE).toInt().coerceAtLeast(16)
        val ch = (sh * SCALE).toInt().coerceAtLeast(16)
        synchronized(store.lock) { store.screenW = sw; store.screenH = sh; store.bitmap = null; store.w = 0 }
        val newReader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        newReader.setOnImageAvailableListener({ onFrame(it) }, bg)
        val dpi = resources.displayMetrics.densityDpi
        val d = vd
        if (d == null) {
            vd = projection!!.createVirtualDisplay("PHANTOM", cw, ch, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, newReader.surface, null, null)
        } else { // Android 14+ allows only ONE virtual display per projection, so resize it instead
            d.resize(cw, ch, dpi); d.surface = newReader.surface
        }
        val old = reader; reader = newReader; old?.close()
    }

    private fun onFrame(r: ImageReader) {
        val img = (try { r.acquireLatestImage() } catch (e: Exception) { null }) ?: return
        try {
            val now = SystemClock.uptimeMillis()
            if (!lensVisible || now - lastFrame < 30) return // ~30 fps cap, idle when nothing is shown
            lastFrame = now
            val plane = img.planes[0]
            val pw = plane.rowStride / plane.pixelStride
            synchronized(store.lock) {
                var b = store.bitmap
                if (b == null || b.width != pw || b.height != img.height) {
                    b = Bitmap.createBitmap(pw, img.height, Bitmap.Config.ARGB_8888); store.bitmap = b
                }
                b.copyPixelsFromBuffer(plane.buffer)
                store.w = img.width; store.h = img.height
                if (++frameCount % 15 == 0) checkBlank(b, img.width, img.height)
            }
            lens?.postInvalidate()
        } catch (e: Exception) { /* drop this frame */ } finally { img.close() }
    }

    /** If the captured frames stay completely black, the content is probably protected from capture. */
    private fun checkBlank(b: Bitmap, w: Int, h: Int) {
        var lit = false
        for (gx in 1..6) for (gy in 1..6) if ((b.getPixel(w * gx / 7, h * gy / 7) and 0xFFFFFF) != 0) lit = true
        blankCount = if (lit) 0 else blankCount + 1
        if (blankCount >= 6 && !warned) {
            warned = true
            main.post { toast("The captured screen is blank. The current app may block screen capture, so the lens can't show it.") }
        }
    }

    // ---------------------------------------------------------------- overlay UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }

    private fun fit(p: WindowManager.LayoutParams) {
        p.x = p.x.coerceIn(0, max(0, store.screenW - p.width))
        p.y = p.y.coerceIn(0, max(0, store.screenH - p.height))
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(v: View, p: WindowManager.LayoutParams,
                              onMove: () -> Unit = {}, onTap: () -> Unit = {}, onEnd: () -> Unit = {}) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moved = true
                    if (moved) { p.x = ox + dx.toInt(); p.y = oy + dy.toInt(); fit(p); wm.updateViewLayout(v, p); onMove() }
                }
                MotionEvent.ACTION_UP -> if (moved) onEnd() else onTap()
            }
            true
        }
    }

    private fun buildUi() {
        val sz = dp(56)
        val tv = TextView(this).apply {
            text = "P"; gravity = Gravity.CENTER; setTextColor(RED); textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(Color.parseColor("#F2000000")); setStroke(dp(2), RED)
            }
        }
        val p = lp(sz, sz).apply {
            x = if (prefs.fabX >= 0) prefs.fabX else dp(16)
            y = if (prefs.fabY >= 0) prefs.fabY else dp(120)
        }
        fit(p)
        makeDraggable(tv, p, onTap = { togglePanel() }, onEnd = { prefs.fabX = p.x; prefs.fabY = p.y })
        wm.addView(tv, p); fab = tv; fabLp = p
        panel = buildPanel()
        refreshLens()
    }

    private fun rounded(fill: Int, stroke: Int, r: Int = 12) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(r).toFloat()
    }

    private fun buildPanel(): View {
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(14)) }
        col.addView(TextView(ctx).apply {
            text = "PHANTOM"; setTextColor(RED); textSize = 20f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.25f
        })
        magSwitch = toggle(ctx, "Magnifier", prefs.magnifierOn) { prefs.magnifierOn = it; refreshLens() }
        filterSwitch = toggle(ctx, "Thermal filter", prefs.filterOn) { prefs.filterOn = it; refreshLens() }
        col.addView(magSwitch); col.addView(filterSwitch)
        col.addView(slider(ctx, "Zoom", 10, 50, prefs.zoomTenths, { "%.1fx".format(it / 10f) }) {
            prefs.zoomTenths = it; lens?.invalidate() })
        col.addView(slider(ctx, "Window size", 120, 400, prefs.lensSizeDp, { "$it dp" }) { v ->
            prefs.lensSizeDp = v
            lensLp?.let { p -> p.width = dp(v); p.height = dp(v); fit(p); lens?.let { wm.updateViewLayout(it, p) } } })
        col.addView(slider(ctx, "Transparency", 30, 100, prefs.opacity, { "$it%" }) {
            prefs.opacity = it; lens?.alpha = it / 100f })
        col.addView(slider(ctx, "Filter intensity", 0, 100, prefs.intensity, { "$it%" }) {
            prefs.intensity = it; lens?.invalidate() })
        val modeBtn = button(ctx, "Mode: ${MODE_NAMES[prefs.mode]}")
        modeBtn.setOnClickListener {
            prefs.mode = (prefs.mode + 1) % MODE_NAMES.size
            modeBtn.text = "Mode: ${MODE_NAMES[prefs.mode]}"; lens?.invalidate()
        }
        col.addView(modeBtn)
        val stop = button(ctx, "Stop PHANTOM"); stop.setOnClickListener { stopSelf() }
        col.addView(stop)
        col.addView(TextView(ctx).apply {
            text = "Drag the red ring to choose what the window shows."; setTextColor(Color.GRAY); textSize = 11f
            setPadding(0, dp(8), 0, 0)
        })
        val sv = ScrollView(ctx).apply { background = rounded(Color.parseColor("#F0050505"), RED, 16); addView(col) }
        panelLp = lp(dp(290), dp(400))
        return sv
    }

    private fun togglePanel() {
        val pv = panel ?: return; val p = panelLp ?: return; val f = fabLp ?: return
        if (panelOpen) { wm.removeView(pv); panelOpen = false; return }
        p.height = min(dp(480), store.screenH - dp(16))
        p.x = if (f.x + dp(64) + p.width <= store.screenW) f.x + dp(64) else max(0, f.x - p.width - dp(8))
        p.y = ((store.screenH - p.height) / 2).coerceAtLeast(0)
        wm.addView(pv, p); panelOpen = true
    }

    private fun toggle(ctx: Context, label: String, on: Boolean, cb: (Boolean) -> Unit) = Switch(ctx).apply {
        text = label; setTextColor(Color.WHITE); textSize = 17f; isChecked = on; setPadding(0, dp(10), 0, dp(10))
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = ColorStateList(states, intArrayOf(RED, Color.GRAY))
        trackTintList = ColorStateList(states, intArrayOf(0x66E5192B, 0x44888888))
        setOnCheckedChangeListener { _, c -> cb(c) }
    }

    private fun slider(ctx: Context, label: String, min: Int, max: Int, cur: Int,
                       fmt: (Int) -> String, onChange: (Int) -> Unit): View {
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, 0) }
        val tv = TextView(ctx).apply { setTextColor(Color.LTGRAY); textSize = 13f; text = "$label  ${fmt(cur)}" }
        val sb = SeekBar(ctx).apply {
            this.max = max - min; progress = cur - min
            progressTintList = ColorStateList.valueOf(RED); thumbTintList = ColorStateList.valueOf(RED)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    tv.text = "$label  ${fmt(p + min)}"; if (fromUser) onChange(p + min)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(tv); box.addView(sb); return box
    }

    private fun button(ctx: Context, label: String) = Button(ctx).apply {
        text = label; setTextColor(Color.WHITE); isAllCaps = false; textSize = 15f
        background = rounded(Color.parseColor("#1A1A1A"), RED, 10)
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) }
    }

    // ---------------------------------------------------------------- lens

    private fun focusPoint(): Pair<Float, Float> {
        val c = cross ?: return store.screenW / 2f to store.screenH / 2f
        c.getLocationOnScreen(loc)
        return (loc[0] + c.width / 2f) to (loc[1] + c.height / 2f)
    }

    private fun refreshLens() {
        val want = prefs.magnifierOn || prefs.filterOn
        if (want && lens == null) showLens() else if (!want && lens != null) hideLens()
        lens?.invalidate()
    }

    private fun showLens() {
        val size = dp(prefs.lensSizeDp)
        val p = lp(size, size).apply {
            x = if (prefs.lensX >= 0) prefs.lensX else store.screenW - size - dp(16)
            y = if (prefs.lensY >= 0) prefs.lensY else dp(16)
        }
        fit(p)
        val csz = dp(56)
        val cp = lp(csz, csz).apply {
            x = if (prefs.focusX >= 0) prefs.focusX else store.screenW / 2 - csz / 2
            y = if (prefs.focusY >= 0) prefs.focusY else store.screenH / 2 - csz / 2
        }
        fit(cp)
        val l = LensView(this, store, prefs, { focusPoint() },
            onDrag = { dx, dy ->
                p.x += Math.round(dx); p.y += Math.round(dy); fit(p); lens?.let { wm.updateViewLayout(it, p) }
            },
            onDragEnd = { prefs.lensX = p.x; prefs.lensY = p.y },
            onClose = { main.post { magSwitch.isChecked = false; filterSwitch.isChecked = false } })
        l.alpha = prefs.opacity / 100f
        val c = CrosshairView(this)
        makeDraggable(c, cp, onMove = { lens?.invalidate() }, onEnd = { prefs.focusX = cp.x; prefs.focusY = cp.y })
        lensVisible = true
        wm.addView(c, cp); cross = c; crossLp = cp
        wm.addView(l, p); lens = l; lensLp = p
    }

    private fun hideLens() {
        lensVisible = false
        lens?.let { rm(it) }; cross?.let { rm(it) }
        lens = null; cross = null
    }

    private fun rm(v: View?) { if (v != null) try { wm.removeView(v) } catch (e: Exception) { } }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (projection == null) return
        main.postDelayed({
            try { setupCapture() } catch (e: Exception) { toast("Capture could not adapt to rotation: ${e.message}") }
            listOf(fab to fabLp, lens to lensLp, cross to crossLp).forEach { (v, p) ->
                if (v != null && p != null) { fit(p); try { wm.updateViewLayout(v, p) } catch (e: Exception) { } }
            }
            if (panelOpen) { togglePanel(); togglePanel() }
        }, 300)
    }

    override fun onDestroy() {
        lensVisible = false
        rm(fab); rm(lens); rm(cross); if (panelOpen) rm(panel)
        vd?.release(); reader?.close()
        projCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop()
        bgThread?.quitSafely()
        super.onDestroy()
    }
}
